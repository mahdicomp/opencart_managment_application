<?php

$_['heading_title']                                 = 'List of devices used';
$_['text_Guest']                                    = 'Guest';
$_['text_active']                                   = 'Active';
$_['text_inactive']                                 = 'Inactive';
$_['text_delete']                                   = 'Delete';
$_['text_Statistics']                               = 'Statistics';
$_['text_Application_installation_number']          = 'Application installation number';
$_['text_Application_installation_number_active']   = 'Active Application installation number';
$_['text_Application_installation_number_ios']      = 'IOS Application installation number';
$_['text_Application_installation_number_android']  = 'Android Application installation number';
$_['text_Update']                                   = 'Update';



$_['text_User']                                     = 'User';
$_['text_version']                                  = 'Version';
$_['text_version_App']                              = 'Version Application';
$_['text_ID_User']                                  = 'ID User';
$_['text_OS_Moblie']                                = 'OS Moblie';
$_['text_Model_Moblie']                             = 'Model Moblie';
$_['text_factory_Moblie']                           = 'Factory Moblie';
$_['text_status']                                   = 'Status';
$_['text_Last_seen']                                = 'Last seen';
$_['text_Installation_Date']                        = 'Installation Date';
$_['text_No_content']                               = 'No content';
$_['text_Management']                               = 'Management';
$_['text_Send_notification']                        = 'Send notification';
$_['text_Plz_waiting']                              = 'Plases Waiting';




$_['text_send_message']                             = 'Send message';
$_['text_Notification_message_title']               = 'Notification message title';
$_['text_Notification_message_text']                = 'Notification message text';
$_['text_Full_text_message']                        = 'Full text message';
$_['text_Send_notification_message']                = 'Send a notification message';
$_['text_Sent']                                     = 'Sent';
