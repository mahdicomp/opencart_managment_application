<?php

$_['heading_title']            = 'Notification Message';
$_['text_delete']              = 'Delete';
$_['text_Messages']            = 'Messages';
$_['text_ID']                  = 'ID';
$_['text_Subject']             = 'Subject';
$_['text_Short_text']          = 'Short text';
$_['text_Date_added']          = 'Date added';
$_['text_No_content']          = 'No content';