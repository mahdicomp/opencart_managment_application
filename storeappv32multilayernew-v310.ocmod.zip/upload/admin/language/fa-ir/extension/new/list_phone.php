<?php

$_['heading_title']                                 = 'لیست دستگاه های مورد استفاده';
$_['text_Guest']                                    = 'مهمان';
$_['text_active']                                   = 'فعال';
$_['text_inactive']                                 = 'غیرفعال';
$_['text_delete']                                   = 'حذف';
$_['text_Statistics']                               = 'آمارگیر';
$_['text_Application_installation_number']          = 'تعداد نصب اپلیکیشن';
$_['text_Application_installation_number_active']   = 'تعداد نصب فعال اپلیکیشن';
$_['text_Application_installation_number_ios']      = 'تعداد نصب اپلیکشن ای او اس';
$_['text_Application_installation_number_android']  = 'تعداد نصب اپلیکشن اندروید';
$_['text_Update']                                   = 'به روز رسانی';;

$_['text_User']                                     = 'کاربر';
$_['text_version']                                  = 'ورژن';
$_['text_version_App']                              = 'ورژن اپلیکیشن';
$_['text_ID_User']                                  = 'آی دی کاربر';
$_['text_OS_Moblie']                                = 'سیستم عامل گوشی همراه';
$_['text_Model_Moblie']                             = 'مدل گوشی همراه';
$_['text_factory_Moblie']                           = 'کارخانه گوشی همراه';
$_['text_status']                                   = 'وضعیت';
$_['text_Last_seen']                                = 'تاریخ آخرین بازدید';
$_['text_Installation_Date']                        = 'تاریخ نصب';
$_['text_No_content']                               = 'بدون محتوا';
$_['text_Management']                               = 'مدیریت';
$_['text_Send_notification']                        = 'ارسال ناتیفیکیشن';
$_['text_Plz_waiting']                              = 'لطفا صبر کنید';




$_['text_send_message']                             = 'ارسال پیام';
$_['text_Notification_message_title']               = 'عنوان پیام ناتیفیکیشن';
$_['text_Notification_message_text']                = 'متن پیام ناتیفیکیشن';
$_['text_Full_text_message']                        = 'متن کامل پیام';
$_['text_Send_notification_message']                = 'ارسال پیام ناتیفیکیشن';
$_['text_Sent']                                     = 'ارسال شد.';
