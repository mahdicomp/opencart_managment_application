<?php
// Heading
$_['heading_title']            = 'پیام ناتیفیکیشن';
$_['text_delete']              = 'حذف';
$_['text_Messages']            = 'پیام ها';
$_['text_ID']                  = 'شناسه';
$_['text_Subject']             = 'عنوان';
$_['text_Short_text']          = 'متن کوتاه';
$_['text_Date_added']          = 'تاریخ افزودن';
$_['text_No_content']          = 'بدون محتوا';

