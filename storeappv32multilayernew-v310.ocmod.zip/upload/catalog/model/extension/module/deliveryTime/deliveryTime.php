<?php
class ModelExtensionModuleDeliveryTimeDeliveryTime extends Model {
    
    
}